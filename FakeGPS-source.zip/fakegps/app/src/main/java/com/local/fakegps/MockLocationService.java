package com.local.fakegps;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Publishes the chosen coordinates through Android's test location providers. */
public class MockLocationService extends Service {

    public static final String ACTION_START = "com.local.fakegps.START";
    public static final String ACTION_STOP = "com.local.fakegps.STOP";
    public static final String EXTRA_LAT = "lat";
    public static final String EXTRA_LNG = "lng";

    private static final String CHANNEL_ID = "fake_gps_status";
    private static final int NOTIFICATION_ID = 1;
    private static final long INTERVAL_MS = 1000L;
    private static final String[] PROVIDERS = {
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER
    };

    static volatile boolean running = false;
    static volatile double currentLat = 0;
    static volatile double currentLng = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> activeProviders = new ArrayList<>();
    private LocationManager locationManager;

    private final Runnable publisher = new Runnable() {
        @Override
        public void run() {
            try {
                publishLocation();
                handler.postDelayed(this, INTERVAL_MS);
            } catch (SecurityException | IllegalArgumentException e) {
                fail();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        currentLat = intent.getDoubleExtra(EXTRA_LAT, currentLat);
        currentLng = intent.getDoubleExtra(EXTRA_LNG, currentLng);
        enterForeground();

        if (!running) {
            try {
                registerProviders();
            } catch (SecurityException e) {
                fail();
                return START_NOT_STICKY;
            }
            if (activeProviders.isEmpty()) {
                fail();
                return START_NOT_STICKY;
            }
            running = true;
        }

        handler.removeCallbacks(publisher);
        handler.post(publisher);
        return START_NOT_STICKY;
    }

    private void registerProviders() {
        for (String provider : PROVIDERS) {
            removeProvider(provider);
            try {
                locationManager.addTestProvider(provider, false, false, false, false,
                        true, true, true, Criteria.POWER_LOW, Criteria.ACCURACY_FINE);
                locationManager.setTestProviderEnabled(provider, true);
                activeProviders.add(provider);
            } catch (IllegalArgumentException ignored) {
                // This device does not expose the provider; continue with the others.
            }
        }
    }

    private void publishLocation() {
        for (String provider : activeProviders) {
            Location location = new Location(provider);
            location.setLatitude(currentLat);
            location.setLongitude(currentLng);
            location.setAltitude(0);
            location.setAccuracy(3f);
            location.setSpeed(0f);
            location.setBearing(0f);
            location.setTime(System.currentTimeMillis());
            location.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
            locationManager.setTestProviderLocation(provider, location);
        }
    }

    private void removeProvider(String provider) {
        try {
            locationManager.removeTestProvider(provider);
        } catch (IllegalArgumentException | SecurityException ignored) {
            // Nothing was registered for this provider.
        }
    }

    private void fail() {
        Toast.makeText(this, R.string.mock_failed, Toast.LENGTH_LONG).show();
        stopSelf();
    }

    private void enterForeground() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(this, MockLocationService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return builder
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle(getString(R.string.notification_title))
                .setContentText(String.format(Locale.US, "%.6f, %.6f", currentLat, currentLng))
                .setContentIntent(openPending)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel,
                        getString(R.string.stop), stopPending).build())
                .setOngoing(true)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(publisher);
        for (String provider : activeProviders) {
            removeProvider(provider);
        }
        activeProviders.clear();
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
