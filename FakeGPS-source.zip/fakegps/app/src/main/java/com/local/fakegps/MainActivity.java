package com.local.fakegps;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQUEST_PERMISSIONS = 10;
    private static final long REFRESH_MS = 1000L;
    private static final String PREFS = "fake_gps";
    private static final String KEY_LAT = "lat";
    private static final String KEY_LNG = "lng";
    private static final String DEFAULT_LAT = "17.385000";
    private static final String DEFAULT_LNG = "78.486700";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView map;
    private EditText latInput;
    private EditText lngInput;
    private TextView status;
    private Button startButton;
    private Button stopButton;

    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            handler.postDelayed(this, REFRESH_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        map = findViewById(R.id.map);
        latInput = findViewById(R.id.lat);
        lngInput = findViewById(R.id.lng);
        status = findViewById(R.id.status);
        startButton = findViewById(R.id.start);
        stopButton = findViewById(R.id.stop);

        SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        latInput.setText(prefs.getString(KEY_LAT, DEFAULT_LAT));
        lngInput.setText(prefs.getString(KEY_LNG, DEFAULT_LNG));

        startButton.setOnClickListener(v -> onStartPressed());
        stopButton.setOnClickListener(v -> stopMock());
        setupMap();
    }

    private void setupMap() {
        map.getSettings().setJavaScriptEnabled(true);
        map.getSettings().setDomStorageEnabled(true);
        map.addJavascriptInterface(new MapBridge(), "Android");
        map.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                showInputOnMap();
            }
        });
        // A real base URL makes the WebView send the Referer that OpenStreetMap tiles require.
        map.loadDataWithBaseURL("https://fakegps.local/", readAsset("map.html"),
                "text/html", "UTF-8", null);
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private void showInputOnMap() {
        double[] point = readCoordinates();
        if (point != null) {
            map.evaluateJavascript(String.format(Locale.US, "setMarker(%.6f,%.6f,true)",
                    point[0], point[1]), null);
        }
    }

    /** Returns {lat, lng}, or null when the typed values are out of range. */
    private double[] readCoordinates() {
        try {
            double lat = Double.parseDouble(latInput.getText().toString().trim());
            double lng = Double.parseDouble(lngInput.getText().toString().trim());
            if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
                return null;
            }
            return new double[]{lat, lng};
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void onStartPressed() {
        if (readCoordinates() == null) {
            Toast.makeText(this, R.string.invalid_coords, Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions();
            return;
        }
        if (!isSelectedMockApp()) {
            showSetupDialog();
            return;
        }
        startMock();
    }

    private void requestNeededPermissions() {
        List<String> permissions = new ArrayList<>();
        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        requestPermissions(permissions.toArray(new String[0]), REQUEST_PERMISSIONS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQUEST_PERMISSIONS) {
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            onStartPressed();
        } else {
            Toast.makeText(this, R.string.need_permission, Toast.LENGTH_LONG).show();
        }
    }

    private boolean isSelectedMockApp() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        return appOps.checkOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION, Process.myUid(),
                getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }

    private void showSetupDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.setup_title)
                .setMessage(R.string.setup_message)
                .setPositiveButton(R.string.open_settings, (dialog, which) -> openDeveloperOptions())
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void openDeveloperOptions() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.settings_unavailable, Toast.LENGTH_LONG).show();
        }
    }

    private void startMock() {
        double[] point = readCoordinates();
        if (point == null) {
            return;
        }
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_LAT, latInput.getText().toString().trim())
                .putString(KEY_LNG, lngInput.getText().toString().trim())
                .apply();

        Intent intent = new Intent(this, MockLocationService.class)
                .setAction(MockLocationService.ACTION_START)
                .putExtra(MockLocationService.EXTRA_LAT, point[0])
                .putExtra(MockLocationService.EXTRA_LNG, point[1]);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        showInputOnMap();
    }

    private void stopMock() {
        stopService(new Intent(this, MockLocationService.class));
    }

    private void refreshStatus() {
        boolean running = MockLocationService.running;
        startButton.setText(running ? R.string.update : R.string.start);
        stopButton.setEnabled(running);
        if (running) {
            status.setText(getString(R.string.status_on,
                    String.format(Locale.US, "%.6f", MockLocationService.currentLat),
                    String.format(Locale.US, "%.6f", MockLocationService.currentLng)));
        } else {
            status.setText(R.string.status_off);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresher);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refresher);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        map.destroy();
        super.onDestroy();
    }

    private class MapBridge {
        @JavascriptInterface
        public void onMapTap(double lat, double lng) {
            runOnUiThread(() -> {
                latInput.setText(String.format(Locale.US, "%.6f", lat));
                lngInput.setText(String.format(Locale.US, "%.6f", lng));
            });
        }
    }
}
